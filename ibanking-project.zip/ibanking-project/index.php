<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>iBanking TDTU - Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .gradient-bg { background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%); }
        .btn-gradient { background: linear-gradient(to right, #2575fc, #6a11cb); }
    </style>
</head>
<body class="bg-gray-50 min-h-screen flex items-center justify-center p-4 gradient-bg">
<div class="flex flex-col lg:flex-row w-full max-w-6xl bg-white rounded-3xl shadow-2xl overflow-hidden">
    <!-- LEFT: LOGO TRƯỜNG – NỀN TỐI ƯU CHO LOGO ĐỎ + XANH -->
    <div class="lg:w-1/2 p-8 lg:p-12 flex items-center justify-center bg-gradient-to-br from-blue-900 via-slate-900 to-slate-800">
        <div class="text-center">
            <img
                    src="assets/logo.png"
                    alt="Logo TDTU"
                    class="w-48 h-48 lg:w-64 lg:h-64 object-contain mx-auto drop-shadow-2xl filter brightness-110"
            >
            <h1 class="text-3xl lg:text-4xl font-bold text-white mt-6 drop-shadow-md">iBanking TDTU</h1>
            <p class="text-lg lg:text-xl text-white opacity-90 mt-2 drop-shadow">Hệ thống thanh toán học phí</p>
        </div>
    </div>

    <!-- Right: Login Form -->
    <div class="lg:w-1/2 p-12 bg-white flex flex-col justify-center">
        <h2 class="text-4xl font-bold text-gray-800 mb-8 text-center">Đăng nhập</h2>
        <form id="loginForm" class="space-y-6">
            <div class="relative">
                <input type="text" id="username" required placeholder="Tên đăng nhập" class="w-full px-5 py-4 rounded-xl border border-gray-300 focus:ring-2 focus:ring-purple-600 focus:border-transparent transition" />
                <span class="absolute right-4 top-5 text-gray-400">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                    </span>
            </div>
            <div class="relative">
                <input type="password" id="password" required placeholder="Mật khẩu" class="w-full px-5 py-4 rounded-xl border border-gray-300 focus:ring-2 focus:ring-purple-600 focus:border-transparent transition" />
                <span class="absolute right-4 top-5 text-gray-400">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 11c1.104 0 2-.896 2-2s-.896-2-2-2-2 .896-2 2 .896 2 2 2zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" /></svg>
                    </span>
            </div>
            <div class="flex justify-between text-sm">
                <a href="#" class="text-purple-600 hover:underline">Quên mật khẩu?</a>
            </div>
            <button type="submit" class="w-full py-4 rounded-xl text-white font-bold text-lg btn-gradient shadow-lg hover:shadow-xl transition transform hover:-translate-y-1">
                Đăng nhập
            </button>
        </form>

        <div class="mt-8 text-center text-gray-500">hoặc đăng nhập với các nền tảng khác</div>
        <div class="flex justify-center space-x-4 mt-4">
            <!-- Google -->
            <button class="p-3 bg-white border border-gray-300 rounded-full hover:shadow-lg hover:border-red-500 transition-shadow">
                <svg class="w-6 h-6" viewBox="0 0 24 24">
                    <path fill="#EA4335" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#4285F4" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                    <path fill="#34A853" d="M12 6.75c1.64 0 3.09.57 4.24 1.68l3.18-3.18C17.46 2.58 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
            </button>
            <!-- Facebook -->
            <button class="p-3 bg-white border border-gray-300 rounded-full hover:shadow-lg hover:border-blue-600 transition-shadow">
                <svg class="w-6 h-6 text-blue-600" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
            </button>
            <!-- X -->
            <button class="p-3 bg-white border border-gray-300 rounded-full hover:shadow-lg hover:border-gray-500 transition-shadow">
                <svg class="w-6 h-6 text-dark-600" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M14.234 10.162 22.977 0h-2.072l-7.591 8.824L7.251 0H.258l9.168 13.343L.258 24H2.33l8.016-9.318L16.749 24h6.993zm-2.837 3.299-.929-1.329L3.076 1.56h3.182l5.965 8.532.929 1.329 7.754 11.09h-3.182z"/>
                </svg>
            </button>
            <!-- LinkedIn -->
            <button class="p-3 bg-white border border-gray-300 rounded-full hover:shadow-lg hover:border-blue-700 transition-shadow">
                <svg class="w-6 h-6 text-blue-700" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9.277h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9.277h3.564v11.175zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                </svg>
            </button>
        </div>
    </div>
</div>

<script>
    document.getElementById('loginForm').onsubmit = async (e) => {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        try {
            const res = await fetch('api/login.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });

            // Xem nội dung thô nếu không phải JSON
            const text = await res.text();
            console.log('Raw response:', text);

            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                alert('Lỗi server: ' + text.substring(0, 200));
                return;
            }

            if (data.success) {
                window.location.href = 'dashboard.php';
            } else {
                alert(data.message || 'Đăng nhập thất bại');
            }
        } catch (err) {
            console.error(err);
            alert('Lỗi kết nối');
        }
    };
</script>
</body>
</html>