<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

// Lấy thông tin user
require 'config.php';
$db = getDB();
$stmt = $db->prepare("SELECT full_name, phone, email, balance FROM users WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>iBanking TDTU - Tuition Payment</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .btn-gradient { background: linear-gradient(to right, #2575fc, #6a11cb); }
        .card { background: white; border-radius: 1.5rem; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
        .step-number { @apply w-10 h-10 rounded-full bg-gradient-to-r from-purple-600 to-blue-600 text-white flex items-center justify-center font-bold text-sm; }
    </style>
</head>
<body class="bg-gradient-to-br from-blue-50 to-purple-50 min-h-screen">
<!-- Header -->
<header class="bg-white shadow-sm">
    <div class="max-w-6xl mx-auto px-6 py-4 flex justify-between items-center">
        <h1 class="text-2xl font-bold text-purple-700">iBanking <span class="text-blue-600">T</span><span class="text-red-600">D</span><span class="text-blue-600">T</span></h1>
        <div class="flex items-center space-x-4">
            <span class="text-gray-700">Xin chào, <strong><?= htmlspecialchars($user['full_name']) ?></strong></span>
            <span class="px-4 py-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-full font-semibold text-sm">
                Số dư: $<?= number_format($user['balance'], 2) ?>
            </span>
            <a href="logout.php" class="text-red-600 hover:underline text-sm">Đăng xuất</a>
        </div>
    </div>
</header>

<main class="max-w-4xl mx-auto p-6 mt-8">
    <!-- Title -->
    <div class="text-center mb-10">
        <h2 class="text-3xl font-bold text-purple-800">Thanh toán học phí</h2>
        <p class="text-gray-600 mt-2">Hoàn thành mẫu dưới đây để thanh toán học phí</p>
    </div>

    <form id="paymentForm" class="space-y-8">
        <!-- 1. Payer Information -->
        <div class="card p-8">
            <div class="flex items-center mb-6">
                <div class="step-number">1</div>
                <h3 class="ml-3 text-xl font-semibold text-gray-800">Thông tin người chuyển</h3>
            </div>
            <div class="grid md:grid-cols-3 gap-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Tên người chuyển</label>
                    <input type="text" value="<?= htmlspecialchars($user['full_name']) ?>" disabled class="w-full px-4 py-3 rounded-lg bg-gray-100 border border-gray-300">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Số điện thoại</label>
                    <input type="text" value="<?= htmlspecialchars($user['phone']) ?>" disabled class="w-full px-4 py-3 rounded-lg bg-gray-100 border border-gray-300">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Địa chỉ email</label>
                    <input type="text" value="<?= htmlspecialchars($user['email']) ?>" disabled class="w-full px-4 py-3 rounded-lg bg-gray-100 border border-gray-300">
                </div>
            </div>
        </div>

        <!-- 2. Tuition Information -->
        <div class="card p-8">
            <div class="flex items-center mb-6">
                <div class="step-number">2</div>
                <h3 class="ml-3 text-xl font-semibold text-gray-800">Thông tin học phí</h3>
            </div>
            <div class="flex items-end space-x-4">
                <div class="flex-1">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Mã số sinh viên *</label>
                    <input type="text" id="studentId" placeholder="Nhập mã số sinh viên (e.g., 52100123)" required class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-purple-600">
                </div>
                <button type="button" onclick="searchStudent()" class="px-6 py-3 bg-gradient-to-r from-teal-500 to-teal-600 text-white rounded-lg font-medium hover:shadow-lg transition">
                    Tìm kiếm
                </button>
            </div>
            <div id="studentInfo" class="mt-6 hidden">
                <div class="grid md:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Họ và tên sinh viên</label>
                        <input type="text" id="studentName" disabled class="w-full px-4 py-3 rounded-lg bg-gray-100 border border-gray-300">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Số tiền học phí</label>
                        <input type="text" id="tuitionAmount" disabled class="w-full px-4 py-3 rounded-lg bg-gray-100 border border-gray-300">
                        <!-- ẨN GIÁ TRỊ SỐ THẬT -->
                        <input type="hidden" id="tuitionAmountRaw">
                    </div>
                </div>
            </div>
        </div>

        <!-- 3. Payment Information -->
        <div class="card p-8">
            <div class="flex items-center mb-6">
                <div class="step-number">3</div>
                <h3 class="ml-3 text-xl font-semibold text-gray-800">Thông tin thanh toán</h3>
            </div>
            <div class="space-y-4">
                <div class="flex justify-between py-2">
                    <span class="text-gray-700">Số dư khả dụng:</span>
                    <span class="font-semibold text-green-600">$<?= number_format($user['balance'], 2) ?></span>
                </div>
                <div class="flex justify-between py-2">
                    <span class="text-gray-700">Số tiền học phí:</span>
                    <span id="paymentAmount" class="font-semibold">$0.00</span>
                </div>
                <div class="flex justify-between py-2 border-t pt-2">
                    <span class="text-gray-700 font-medium">Số dư còn lại:</span>
                    <span id="remainingBalance" class="font-semibold text-purple-600">$<?= number_format($user['balance'], 2) ?></span>
                </div>
            </div>
            <div class="mt-6 flex items-start">
                <input type="checkbox" id="agree" required class="mt-1">
                <label for="agree" class="ml-3 text-sm text-gray-600">
                    Tôi đồng ý với các <a href="#" class="text-purple-600 underline">Điều khoản và Điều kiện</a> và xác nhận rằng thông tin thanh toán là chính xác.
                </label>
            </div>
        </div>

        <!-- Confirm Button -->
        <div class="text-center">
            <button type="submit" id="confirmBtn" disabled class="w-full max-w-md py-4 rounded-xl text-white font-bold text-lg btn-gradient shadow-lg hover:shadow-xl transition transform hover:-translate-y-1 disabled:opacity-50 disabled:cursor-not-allowed">
                Xác nhận giao dịch
            </button>
        </div>

        <!-- LỊCH SỬ GIAO DỊCH -->
        <div class="mt-12 bg-white p-6 rounded-xl shadow-lg">
            <h3 class="text-2xl font-bold text-gray-800 mb-4">Lịch sử giao dịch</h3>
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                    <tr class="border-b">
                        <th class="py-2 px-4 text-gray-600">Mã SV</th>
                        <th class="py-2 px-4 text-gray-600">Họ tên</th>
                        <th class="py-2 px-4 text-gray-600">Số tiền</th>
                        <th class="py-2 px-4 text-gray-600">Thời gian</th>
                        <th class="py-2 px-4 text-gray-600">Trạng thái</th>
                    </tr>
                    </thead>
                    <tbody id="historyTable">
                    <!-- Dữ liệu sẽ được load bằng JS -->
                    </tbody>
                </table>
            </div>
        </div>
    </form>

    <!-- OTP Modal -->
    <div id="otpModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
        <div class="bg-white rounded-2xl p-8 max-w-md w-full mx-4">
            <h3 class="text-2xl font-bold text-center mb-4">Nhập mã OTP</h3>
            <p class="text-center text-gray-600 mb-6">Chúng tôi đã gửi mã OTP 6 chữ số đến email của bạn.</p>
            <input type="text" id="otpInput" maxlength="6" placeholder="000000" class="w-full text-center text-3xl font-mono tracking-widest py-4 rounded-lg border border-gray-300 focus:ring-2 focus:ring-purple-600">
            <button onclick="verifyOTP()" class="mt-6 w-full py-3 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg font-semibold hover:shadow-lg transition">
                Xác thực
            </button>
        </div>
    </div>
</main>

<script>
    let transactionId = null;
    const balance = <?= $user['balance'] ?>;

    function searchStudent() {
        const studentId = document.getElementById('studentId').value.trim();
        if (!studentId) return alert('Vui lòng nhập mã số sinh viên');

        fetch(`api/get-student.php?student_id=${studentId}`)
            .then(res => res.json())
            .then(data => {
                const info = document.getElementById('studentInfo');
                if (data.full_name) {
                    document.getElementById('studentName').value = data.full_name;

                    // Hiển thị có định dạng
                    document.getElementById('tuitionAmount').value = '$' + Number(data.tuition_due).toLocaleString();

                    // Lưu giá trị số thật vào hidden
                    document.getElementById('tuitionAmountRaw').value = data.tuition_due;

                    document.getElementById('paymentAmount').textContent = '$' + Number(data.tuition_due).toLocaleString();
                    document.getElementById('remainingBalance').textContent = '$' + Number(balance - data.tuition_due).toLocaleString();
                    info.classList.remove('hidden');
                    checkForm();
                } else {
                    // alert(data.message || 'Student not found');
                    const msg = data.message;
                    if (msg.includes('đã được thanh toán') || msg.includes('không tồn tại')) {
                        alert(msg);
                        document.getElementById('studentInfo').classList.add('hidden');
                        document.getElementById('confirmBtn').disabled = true;
                    } else {
                        alert(msg);
                    }
                }
            })
            .catch(err => {
                console.error(err);
                alert('Lỗi kết nối đến server');
            });
    }

    function checkForm() {
        const studentId = document.getElementById('studentId').value;
        const amount = parseFloat(document.getElementById('tuitionAmountRaw').value) || 0;
        const agree = document.getElementById('agree').checked;
        document.getElementById('confirmBtn').disabled = !(studentId && amount > 0 && amount <= balance && agree);
    }

    document.getElementById('paymentForm').onsubmit = async (e) => {
        e.preventDefault();
        const student_id = document.getElementById('studentId').value;
        const amount = parseFloat(document.getElementById('tuitionAmountRaw').value); // ĐÃ SỬA

        if (isNaN(amount) || amount <= 0) {
            alert('Số tiền không hợp lệ');
            return;
        }

        try {
            const res = await fetch('api/create-transaction.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ student_id, amount })
            });

            const text = await res.text();
            console.log('Raw response:', text);

            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                alert('Lỗi server: ' + text.substring(0, 200));
                return;
            }

            if (data.success) {
                transactionId = data.transaction_id;
                document.getElementById('otpModal').classList.remove('hidden');
                setTimeout(() => {
                    alert(`OTP đã được gửi! Vui lòng kiểm tra email của bạn.\nTransaction ID: ${transactionId}`);
                }, 500);
            } else {
                alert(data.message);
            }
        } catch (err) {
            console.error(err);
            alert('Lỗi kết nối');
        }
    };

    async function verifyOTP() {
        const otp = document.getElementById('otpInput').value.trim();
        if (otp.length !== 6 || !/^\d+$/.test(otp)) {
            alert('Vui lòng nhập mã OTP 6 chữ số');
            return;
        }

        try {
            const res = await fetch('api/verify-otp.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ transaction_id: transactionId, otp })
            });

            const text = await res.text();
            console.log('Raw response:', text); // Debug

            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                alert('Lỗi server: Phản hồi không phải JSON');
                console.error('Invalid JSON:', text);
                return;
            }

            if (data.success) {
                alert(data.message);
                setTimeout(() => location.reload(), 1500);
            } else {
                alert(data.message);
            }
        } catch (err) {
            console.error(err);
            alert('Lỗi kết nối');
        }
    }

    // Enable confirm button
    document.getElementById('agree').onchange = checkForm;
    document.getElementById('studentId').oninput = () => setTimeout(checkForm, 500);

    async function loadHistory() {
        try {
            const res = await fetch('api/get-history.php');
            const data = await res.json();
            if (data.success) {
                const tbody = document.getElementById('historyTable');
                tbody.innerHTML = data.data.map(row => `
                <tr class="border-b hover:bg-gray-50">
                    <td class="py-3 px-4">${row.student_id}</td>
                    <td class="py-3 px-4">${row.full_name}</td>
                    <td class="py-3 px-4 text-green-600 font-medium">$${Number(row.amount).toLocaleString()}</td>
                    <td class="py-3 px-4 text-gray-600">${new Date(row.completed_at).toLocaleDateString('vi-VN')}</td>
                    <td class="py-3 px-4"><span class="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">Hoàn thành</span></td>
                </tr>
            `).join('');
            }
        } catch (err) {
            console.error(err);
        }
    }

    // Load khi vào trang
    window.addEventListener('load', loadHistory);
</script>
</body>
</html>