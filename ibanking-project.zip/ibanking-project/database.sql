CREATE DATABASE ibanking;
USE ibanking;

CREATE TABLE users (
                       user_id INT AUTO_INCREMENT PRIMARY KEY,
                       username VARCHAR(50) UNIQUE NOT NULL,
                       password VARCHAR(255) NOT NULL,
                       full_name VARCHAR(100) NOT NULL,
                       phone VARCHAR(20) NOT NULL,
                       email VARCHAR(100) NOT NULL,
                       balance DECIMAL(15,2) DEFAULT 0.00,
                       transaction_history TEXT
);

CREATE TABLE students (
                          student_id VARCHAR(20) PRIMARY KEY,
                          full_name VARCHAR(100) NOT NULL,
                          tuition_due DECIMAL(15,2) DEFAULT 0.00
);

CREATE TABLE transactions (
                              transaction_id INT AUTO_INCREMENT PRIMARY KEY,
                              user_id INT NOT NULL,
                              student_id VARCHAR(20) NOT NULL,
                              amount DECIMAL(15,2) NOT NULL,
                              timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                              status ENUM('pending', 'success', 'failed') DEFAULT 'pending',
                              FOREIGN KEY (user_id) REFERENCES users(user_id),
                              FOREIGN KEY (student_id) REFERENCES students(student_id)
);

CREATE TABLE otps (
                      otp_id INT AUTO_INCREMENT PRIMARY KEY,
                      transaction_id INT NOT NULL,
                      code VARCHAR(6) NOT NULL,
                      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                      expires_at DATETIME NOT NULL,
                      used TINYINT(1) DEFAULT 0,
                      FOREIGN KEY (transaction_id) REFERENCES transactions(transaction_id)
);

INSERT INTO users (username, password, full_name, phone, email, balance) VALUES
                                                                                   ('hueminh', '$2y$12$GRZp.8Njk7qI5ReKagZ0X.HR/h/JCpgPMs68aH4bEdBEgJH0lwhRy', 'Hy Hue Minh', '0901234567', 'hyhueminh@gmail.com', 5000000.00),
                                                                                   ('nguyenvana', '$2y$12$GRZp.8Njk7qI5ReKagZ0X.HR/h/JCpgPMs68aH4bEdBEgJH0lwhRy', 'Nguyen Van A', '0912345678', 'nguyenvana@tdtu.edu.vn', 10000000.00),
                                                                                   ('tranthib', '$2y$12$GRZp.8Njk7qI5ReKagZ0X.HR/h/JCpgPMs68aH4bEdBEgJH0lwhRy', 'Tran Thi B', '0923456789', 'tranthib@tdtu.edu.vn', 3000000.00);

INSERT INTO students (student_id, full_name, tuition_due) VALUES
                                                              ('52100123', 'Nguyen Thi Kim Anh', 4500000.00),
                                                              ('52200234', 'Le Van Minh', 5200000.00),
                                                              ('52300345', 'Pham Hoang Long', 3800000.00),
                                                              ('52400456', 'Vu Thi Mai', 0.00), -- Đã thanh toán
                                                              ('52500567', 'Do Quang Huy', 6000000.00);