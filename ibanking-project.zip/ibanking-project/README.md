# iBanking TDTU
**Hệ thống thanh toán học phí trực tuyến – Đồ án giữa kỳ môn Kiến trúc hướng dịch vụ**

![Logo TDTU](assets/logo.png)

---

## MÔ TẢ DỰ ÁN

**iBanking TDTU** là hệ thống **thanh toán học phí an toàn, bảo mật, hiện đại** cho **phụ huynh sinh viên Đại học Tôn Đức Thắng**.  
Hỗ trợ:
- Tìm kiếm sinh viên theo **mã số sinh viên**
- Thanh toán **một chạm** với **xác thực OTP qua email**
- Xem **lịch sử giao dịch**

---

## TÍNH NĂNG CHÍNH

| Tính năng | Mô tả |
|--------|-------|
| **Đăng nhập an toàn** | Mật khẩu mã hóa `password_hash()` |
| **Tìm sinh viên** | Nhập MSSV → hiện tên + học phí |
| **Xác nhận thanh toán** | Kiểm tra số dư + tạo giao dịch |
| **OTP qua email** | Gửi mã 6 số → hết hạn 5 phút |
| **Xác thực OTP** | Nhập mã → trừ tiền + cập nhật trạng thái |
| **Lịch sử giao dịch** | Xem chi tiết đã thanh toán |
| **Chống thanh toán trùng** | Không cho thanh toán 2 lần cùng SV |

---

## CÔNG NGHỆ SỬ DỤNG

```text
Frontend: HTML5, CSS3 (Tailwind), JavaScript (fetch API)
Backend: PHP 8+, PDO, Session
Database: MySQL
Email: PHPMailer + Gmail SMTP
Tools: XAMPP, Postman, draw.io, ERDPlus, Visual Studio Code
```

---

## CẤU TRÚC THƯ MỤC
ibanking-project/
├── index.php                                               → Trang đăng nhập
├── dashboard.php                                           → Trang chính
├── api/
│   ├── login.php                                           → API đăng nhập
│   ├── get-student.php                                     → API tìm sinh viên
│   ├── create-transaction.php                              → API tạo giao dịch + OTP
│   ├── verify-otp.php                                      → API xác thực OTP
│   └── get-history.php                                     → API lịch sử
├── config.php                                              → Cấu hình DB + PHPMailer
├── assets/
│   └── logo.png                                            → Logo TDTU
├── docs/
│   ├── ERD1.png                                            → Ảnh ERD
│   ├── ERD2.png                                            → Ảnh ERD
│   └── useCase.png                                         → Ảnh Use Case Diagram
├── postman/
│   └── iBanking TDTU.postman_collection.json               → Collection test API
├── database.sql                → Script tạo CSDL
└── README.md                   → Hướng dẫn

---

## HƯỚNG DẪN CÀI ĐẶT
## I. Yêu cầu
- XAMPP (Apache + )
- Composer (để cài PHPMailer)
## II. Các bước
1. Mở XAMPP -> Bật Apache và MySQL
2. Clone project
- git clone
3. Cài PHPMailer
- cd ibanking-project
- composer require phpmailer/phpmailer
4. Tạo CSDL
- Mở phpMyAdmin: http://localhost/phpmyadmin
- Tạo DB: ibanking
- Import file database.sql
5. Cấu hình email (tuỳ chọn)
- Mở config.php
- Thay:
- "$mail→Username = 'your-email@gmail.com';"
-  "$mail→Password = 'your-app-password';"

---

## DEMO NHANH
## I. Tài khoản mẫu (đã có trong DB)


| Tên đăng nhập    | Mật khẩu |
|------------------|----------|
| **lamkhang**     | 123456   |
| **hyhueminh**    | 123456   |
| **leminhnguyen** | 123456   |

## II. Sinh viên mẫu

| Mã số sinh viên | Họ và tên     | Số tiền học phí |
|-----------------|---------------|----------------|
| **525H0038**    | Mai Duy Khang | 500.000        | |


## III. Các bước demo
1. **Mở trình duyệt** → http://localhost/ibanking-project
2. **Đăng nhập:** hyhueminh / 123456
3. **Nhập MSSV:** 525H0038 → hiện tên + học phí
4. **Nhấn "Xác nhận thanh toán"**
5. **Kiểm tra email** → nhập OTP → **Thành công!**
6. **Xem lịch sử** → thấy giao dịch vừa thanh toán

---

## TEST API BẰNG POSTMAN
1. Mở **Postman** → **Import** → chọn file
2. Chạy theo thứ tự:
* Login → lấy session
* Get Student
* Create transaction
* Verify OTP
* Get History

---

## CƠ SỞ DỮ LIỆU (ERD)

- **File ERD:** https://drive.google.com/file/d/1j7AxPwzxRLbjomgnqq7NEZ_c00GQ3Zig/view?usp=sharing
- **Quan hệ:**
- users → transactions (**1:N** - 1 user có nhiều giao dịch)
- students → transactions (**1:N** - 1 sinh viên được thanh toán nhiều lần)
- transactions → otps (**1:1** - 1 giao dịch có 1 OTP)

---

## ĐÓNG GÓP & LIÊN HỆ
* **Tác giả:** Lâm Khang, Hy Huê Minh, Lê Minh Nguyên
* **MSSV:** 523H0038, 523H0052, 523H0063
* **Email:** 
* * lamkhang.lv.9d2@gmail.com (Lâm Khang)
* * hyphubao.21092005@gmail.com (Hy Huê Minh)
* * theman14112005@gmail.com (Lê Minh Nguyên)
