<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

require '../config.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$student_id = $data['student_id'] ?? '';
$amount = $data['amount'] ?? 0;

if (empty($student_id) || $amount <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid data']);
    exit;
}

$db = getDB();
$db->beginTransaction();

try {
    // DÙNG FOR UPDATE → KHÓA DÒNG, NGĂN GHI ĐỒNG THỜI
    $stmt = $db->prepare("SELECT balance FROM users WHERE user_id = ? FOR UPDATE");
    $stmt->execute([$_SESSION['user_id']]);
    $balance = floatval($stmt->fetchColumn());

    $stmt = $db->prepare("SELECT tuition_due FROM students WHERE student_id = ? FOR UPDATE");
    $stmt->execute([$student_id]);
    $tuition_due = floatval($stmt->fetchColumn());

    $amount = floatval($amount);

    if ($tuition_due <= 0) {
        throw new Exception('Student has no tuition due');
    }
    if ($amount != $tuition_due) {
        throw new Exception("Amount mismatch: sent $amount, expected $tuition_due");
    }
    if ($amount > $balance) {
        throw new Exception('Insufficient balance');
    }

    // TẠO GIAO DỊCH
    $stmt = $db->prepare("INSERT INTO transactions (user_id, student_id, amount) VALUES (?, ?, ?)");
    $stmt->execute([$_SESSION['user_id'], $student_id, $amount]);
    $transaction_id = $db->lastInsertId();

    // TẠO OTP DUY NHẤT
    do {
        $otp = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
        $stmt = $db->prepare("SELECT COUNT(*) FROM otps WHERE code = ?");
        $stmt->execute([$otp]);
    } while ($stmt->fetchColumn() > 0);

    $expires_at = date('Y-m-d H:i:s', time() + 300);
    $stmt = $db->prepare("INSERT INTO otps (transaction_id, code, expires_at) VALUES (?, ?, ?)");
    $stmt->execute([$transaction_id, $otp, $expires_at]);

    // GỬI EMAIL
    $stmt = $db->prepare("SELECT email FROM users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $email = $stmt->fetchColumn();

    if (!$email) {
        throw new Exception('Không tìm thấy email người dùng');
    }

    $body = "<h3>Mã OTP của bạn</h3><p>Mã OTP: <strong style='font-size: 1.5em;'>$otp</strong></p><p>Hết hạn sau 5 phút.</p>";
    sendEmail($email, 'OTP Code', $body);

    // COMMIT → HOÀN TẤT
    $db->commit();

    echo json_encode(['success' => true, 'transaction_id' => $transaction_id]);

} catch (Exception $e) {
    $db->rollback();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>