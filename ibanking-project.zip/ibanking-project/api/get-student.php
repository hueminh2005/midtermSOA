<?php
session_start();
require '../config.php';
header('Content-Type: application/json');

$student_id = $_GET['student_id'] ?? '';
if (empty($student_id)) {
    echo json_encode(['message' => 'Vui lòng nhập mã số sinh viên']);
    exit;
}

$db = getDB();

// 1. LẤY THÔNG TIN SINH VIÊN
$stmt = $db->prepare("SELECT full_name, tuition_due FROM students WHERE student_id = ?");
$stmt->execute([$student_id]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    echo json_encode(['message' => 'Sinh viên không tồn tại']);
    exit;
}

// 2. KIỂM TRA ĐÃ THANH TOÁN CHƯA (với user hiện tại)
$stmt = $db->prepare("
    SELECT COUNT(*) 
    FROM transactions 
    WHERE student_id = ? 
      AND user_id = ? 
      AND status = 'completed'
");
$stmt->execute([$student_id, $_SESSION['user_id']]);
$paid = $stmt->fetchColumn() > 0;

if ($paid) {
    echo json_encode(['message' => 'Học phí của sinh viên này đã được thanh toán']);
    exit;
}

// 3. TRẢ VỀ THÔNG TIN (nếu chưa thanh toán)
echo json_encode([
    'full_name' => $student['full_name'],
    'tuition_due' => $student['tuition_due']
]);
?>