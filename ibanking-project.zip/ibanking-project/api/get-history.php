<?php
session_start();
require '../config.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$db = getDB();
$stmt = $db->prepare("
    SELECT t.student_id, s.full_name, t.amount, t.completed_at, t.status 
    FROM transactions t 
    JOIN students s ON t.student_id = s.student_id 
    WHERE t.user_id = ? AND t.status = 'completed'
    ORDER BY t.completed_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$history = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode(['success' => true, 'data' => $history]);
?>