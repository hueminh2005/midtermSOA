<?php
require '../config.php';
header('Content-Type: application/json');
session_start(); // BẮT BUỘC PHẢI CÓ

// Bật hiển thị lỗi (chỉ để test)
error_reporting(E_ALL);
ini_set('display_errors', 1);

$data = json_decode(file_get_contents('php://input'), true);
$username = $data['username'] ?? '';  // SỬA: XÓA $ THỪA
$password = $data['password'] ?? '';

if (empty($username) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Username and password required']);
    exit;
}

try {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['user_id'];
        echo json_encode([
            'success' => true,
            'user' => [
                'full_name' => $user['full_name'],
                'phone' => $user['phone'],
                'email' => $user['email'],
                'balance' => $user['balance']
            ]
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Sai tài khoản hoặc mật khẩu']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()]);
}
?>