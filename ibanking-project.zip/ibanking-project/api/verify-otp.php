<?php
// BƯỚC 1: BẮT ĐẦU SESSION + ĐẶT HEADER NGAY
session_start();
header('Content-Type: application/json');

// BƯỚC 2: KIỂM TRA ĐĂNG NHẬP
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

require '../config.php';

// BƯỚC 3: ĐỌC DỮ LIỆU
$data = json_decode(file_get_contents('php://input'), true);
$transaction_id = $data['transaction_id'] ?? 0;
$otp = $data['otp'] ?? '';

if ($transaction_id <= 0 || strlen($otp) !== 6) {
    echo json_encode(['success' => false, 'message' => 'Dữ liệu không hợp lệ']);
    exit;
}

$db = getDB();

try {
    $db->beginTransaction();

    // SỬA: DÙNG t.transaction_id
    $stmt = $db->prepare("
        SELECT o.code, o.expires_at, t.amount, t.student_id, t.status 
        FROM otps o 
        JOIN transactions t ON o.transaction_id = t.transaction_id 
        WHERE o.transaction_id = ? AND t.user_id = ?
    ");
    $stmt->execute([$transaction_id, $_SESSION['user_id']]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        throw new Exception('Giao dịch không tồn tại');
    }

    if ($row['status'] !== 'pending') {
        throw new Exception('Giao dịch đã được xử lý');
    }

    if ($row['code'] !== $otp) {
        throw new Exception('Mã OTP không hợp lệ');
    }

    if (strtotime($row['expires_at']) < time()) {
        throw new Exception('Mã OTP đã hết hạn');
    }

    // TRỪ TIỀN
    $amount = floatval($row['amount']);
    $stmt = $db->prepare("UPDATE users SET balance = balance - ? WHERE user_id = ? AND balance >= ?");
    $stmt->execute([$amount, $_SESSION['user_id'], $amount]);
    if ($stmt->rowCount() === 0) {
        throw new Exception('Số dư không đủ');
    }

    // CẬP NHẬT GIAO DỊCH
    $stmt = $db->prepare("UPDATE transactions SET status = 'completed', completed_at = NOW() WHERE transaction_id = ?");
    $stmt->execute([$transaction_id]);

    // XÓA OTP
    $stmt = $db->prepare("DELETE FROM otps WHERE transaction_id = ?");
    $stmt->execute([$transaction_id]);

    $db->commit();

    // CHỈ TRẢ VỀ JSON
    echo json_encode([
        'success' => true,
        'message' => 'Thanh toán thành công!'
    ]);

} catch (Exception $e) {
    $db->rollback();
    // CHỈ TRẢ VỀ JSON
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>